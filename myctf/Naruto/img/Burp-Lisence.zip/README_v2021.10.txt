
1. Download latest version BS
                       👇🏼
https://t.me/burpsuite


2. Place the 2 files in the same directory, then run:

if Windows 💠:

"C:\Program Files\Java\jdk-13.0.2\bin\java.exe" -javaagent:BurpSuiteLoader_v2021.10.jar -noverify -jar burpsuite_pro_v2021.10.jar

https://techaware.netlify.app/posts/2020-12-12-burp-suite-pro/
NB: Java version 9+ required [ filehorse.com/download-java-development-kit-64/46499/download ]

if Linux 🐧:

open burp
           👇🏼
java -javaagent:BurpSuiteLoader_v2021.10.jar -noverify -jar burpsuite_pro_v2021.10.jar

open keygen(activator) 
                   👇🏼
java -jar burploader-old.jar

Then follow video https://t.me/burpsuite/188 above to activate. 🏅

3. If you have problems with activate license, you should use to reactivate old burploader (for older versions like 2.1.07). Run:

java -jar burploader-old.jar

4. activate burp license manually with burploader-old.jar:

copy license request from loaded burpsuite_pro_v2021.10.jar to burploader-old, copy license response and paste to BurpSuite, press next. Done.

P.S.: There we use the same loader as in 2020.4 version (https://github.com/x-Ai/BurpSuiteLoader).

P.P.S.: burp/StartBurp has been compiled by a new version of the Java Runtime (class file version 53.0).
You should use java9+

P.P.P.S.: If you have a problems with activation, try activate 2020.12 version, it could help you.